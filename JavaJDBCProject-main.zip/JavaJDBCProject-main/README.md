# JavaJDBCProject

# Rating Students Using Database – JDBC

* Expectations: Build a solution to illustrate
• If user enters student id, then it should display average scores per assignment category for each
subject.
• If user enters subject id, then it should display average scores per assignment category for all students
• Unit test scripts with report log for all requirements.
