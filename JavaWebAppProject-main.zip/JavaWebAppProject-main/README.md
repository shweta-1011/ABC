# JavaWebAppProject

# Rating Students WebApp+JDBC

* Expectations: Build a solution to illustrate
    • Create UI form for creating “Assignment Category” details
    • Create UI form for Student enrollment for “assignment” (optional)
    • Create UI form for updating ‘date of submission’ & score against enrolled assignment
    • Create Suitable UI for below mentioned requirement(s)
          o To accept student id to display average scores per assignment category for each subject. 
              ▪ If invalid id entered, display with suitable message
          o To accept subject id to display average scores per assignment category for all students
